<?php

include_once 'dbconnect_inc.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id = $_POST['id'];
    $file = $_POST['file'];
    $description = $_POST['description'];
    $URL = $_POST['URL'];

    try {
        $sql = "UPDATE files SET `File Name` = :file, `File Description` = :description, `URL` = :URL WHERE `id` = :id";
        $stmt = $dbHandler->prepare($sql);
        $stmt->bindParam(':id', $id, PDO::PARAM_INT); 
        $stmt->bindParam(':file', $file, PDO::PARAM_STR);
        $stmt->bindParam(':description', $description, PDO::PARAM_STR);
        $stmt->bindParam(':URL', $URL, PDO::PARAM_STR);
        $stmt->execute();
        echo "File updated successfully!";
    } catch (Exception $ex) {
        printError($ex);
    }
}

?>