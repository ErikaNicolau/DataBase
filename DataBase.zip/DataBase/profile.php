<?php
    session_start();
    $msgs = [];
    if(!isset($_SESSION["username"]) && $_SESSION["username"]!='Admin'){
        $msgs[] = "Only the Admin can see this page...";
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="stylesheet.css" rel="stylesheet" type="text/css">
    <title>Intranet</title>
</head>
<body>
  <section class="content">
    <div class="school">
        <ul class="image-list">
            <li>
              <img src="./images/school.png" alt="school_icon">
              <div class="image-label"><h3>The Morningstar</h3></div>
            </li>
            <li>
            </li>
        </ul>
    </div>
    <section class="menu">
        <ul class="image-list">
            <li>
              <img src="./images/home.png" alt="Home_icon">
              <div class="image-label">Home</div>
            </li>
            <li>
              <img src="./images/multiple-users-silhouette.png" alt="attendance_icon">
              <div class="image-label">Attendance</div>
            </li>
            <li>
              <img src="./images/calendar.png" alt="appoinments_icon">
              <div class="image-label">Appoinments</div>
            </li>
            <li>
                <img src="./images/megaphone.png" alt="announcements_icon">
                <div class="image-label">Announcements</div>
            </li>
            <li>
                <img src="./images/newspaper.png" alt="events_icon">
                <div class="image-label">Events</div>
            </li>
            <li>
                <img src="./images/open-folder.png" alt="Courses_icon">
                <div class="image-label">Courses</div>
            </li>
            <li>
                <img src="./images/graphic-progression.png" alt="Progress_icon">
                <div class="image-label">Progress</div>
            </li>
          </ul>
    </section>
    <section class="user">
        <div class="user-name">
        <h2>Admin</h2>
        </div>
        <div class="logout">
            <ul class="image-list2">
                <li>
                  <img src="./images/user_1077114.png" alt="Account_icon">
                  <div class="image-label2"><?php echo $_SESSION["username"] ?></div>
                </li>
                <li>
                  <img src="./images/logout.png" alt="logout_icon">
                  <div class="image-label2"><a href='logout.php'>Log out</a></div>
                </li>
            </ul>
        </div>
    </section>
  <main>
<div class="caset"><h4>Staff members</h4></div>
<ul class="image-list3">
  <li>
    <img src="./images/teacher_3307318.png" alt="Teacher_icon">
    <div class="image-label2"><i>Teachers</i></div>
  </li>
  <li>
    <img src="./images/15763841651530513411-128.png" style="height:165px" alt="Support_icon">
    <div class="image-label2"><i>Support Staff</i></div>
  </li>
  <li>
    <img src="./images/team_2914248.png" alt="Managers_icon">
    <div class="image-label2"><i>Managers</i></div>
  </li>
</ul>
<div class="caset"><h4>Students</h4></div>
<ul class="image-list3">
  <li>
    <img src="./images/multiple-users-silhouette.png" alt="Students_icon">
    <div class="image-label2"><i>Students</i></div>
  </li>
</ul>
<div class="caset"><h4><a href='folder.php'>Private folder</h4></a></div>
<ul class="image-list3">
  <li>
    <img src="./images/452429571595234776-128.png" alt="Private_icon">
  </li>
</ul>
  </main>  
</section>
</body>
</html>