<?php
session_start();
$msgs = [];

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (!$user = filter_input(INPUT_POST, "un", FILTER_SANITIZE_SPECIAL_CHARS)) {
        $msgs[] = "Invalid username or no username given";
    } else if (!$pass = filter_input(INPUT_POST, "pw")) {
        $msgs[] = "No password given";
    }

    if (count($msgs) == 0) {
        require_once("dbconnect_inc.php");
        if ($dbHandler) {
            try {
                $stmt = $dbHandler->prepare("SELECT *
                                             FROM `users`
                                             WHERE `username` = :username"
                );
                $stmt->bindParam("username", $user, PDO::PARAM_STR);
                $stmt->execute();
            } catch (Exception $ex) {
                printError($ex);
            }
        }

        if ($stmt && $stmt->rowCount() == 1) {
            $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
            if (password_verify($pass, $results[0]["password"])) {
                $_SESSION["username"] = $results[0]["username"];
                header("location: profile.php");
                exit();
            } else {
                $msgs[] = "Invalid username or password";
            }
        } else {
            $msgs[] = "Invalid username or password";
        }
        
        $_SESSION["login_msgs"] = $msgs;
        header("location: login.php");
        exit();
    }
}

$display_msgs = isset($_SESSION["login_msgs"]) ? $_SESSION["login_msgs"] : [];
unset($_SESSION["login_msgs"]); 
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link href="stylesheet.css" rel="stylesheet" type="text/css">
    <title>Login please</title>
</head>
<body>
<section class='login'>
    <div class='login-container'>
        <div class='login-box'>
            <h1>Login</h1>
            <?php
            if (count($display_msgs) > 0) {
                foreach ($display_msgs as $msg) {
                    echo "<p class='error-message'>$msg</p>";
                }
            }
            ?>
            <form action="<?= htmlentities($_SERVER['PHP_SELF']) ?>" method="post">
                <table>
                    <tr>
                        <td>Username:</td>
                        <td><input type="text" name="un" /></td>
                    </tr>
                    <tr>
                        <td>Password:</td>
                        <td><input type="password" name="pw" /></td>
                    </tr>
                </table>
                <input type="submit" name="submit" />
                <p>If you do not have an account yet, please <a href='register.php'>register first</a>!
            </form>
        </div>
    </div>
</section>
</body>
</html>