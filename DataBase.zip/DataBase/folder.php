<?php

include_once 'dbconnect_inc.php';

if ($dbHandler) {
    try { 
        $sql = "SELECT * FROM files";
        $stmt = $dbHandler->prepare($sql);
        $stmt->execute();
        $data = $stmt->fetchAll();
    } catch (Exception $ex) {
        printError($ex);
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="stylesheet.css" rel="stylesheet" type="text/css">
    <title>Folder</title>
</head>
<body>
<section class='login'>
    <div class='login-container'>
        <div class='login-box'>
    <h1>Private files</h1>
    <table>
        <tr>
            <th>ID</th>
            <th>File Name</th>
            <th>File Description</th>
            <th>URL</th>
        </tr>
        <?php
    if ($data) {
        foreach ($data as $row) {
            echo '<tr>';
            echo '<td>' . $row["id"] . '</td>';
            echo '<td>' . $row["File Name"] . '</td>';  
            echo '<td>' . $row["File Description"] . '</td>';  
            echo '<td><a href="./files/' . $row["URL"] . '">' . $row["URL"] . '</a></td>';  
            echo '<td><a href="editfile.php?id=' . $row["id"] . '">Edit</a></td>';
            echo '<td><a href="delete.php?id=' . $row["id"] . '">Delete</a></td>';
            echo '</tr>';
        }
} else {
    echo "<tr><td colspan='7'>No results</td></tr>";
}
?>
    </table>
    <br>
    <a href="addfile.php">Add new file</a>
    </div>
</div>
</section>
</body>
</html>