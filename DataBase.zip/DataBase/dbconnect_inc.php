<?php

$sName="localhost";
$uName="root";
$pass="qwerty";
$dbname="morningstar";

$dbHandler=null;
try{
    $dbHandler=new PDO("mysql:host=mysql; dbname=morningstar;charset=utf8" , "root", "qwerty");}
catch(Exception $ex){printError($ex);}

function printError(String $err){
echo"<h1>The following error occured</h1>
<p>{$err}</p>";}

