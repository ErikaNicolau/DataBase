<?php
include('dbconnect_inc.php');

if ($_SERVER["REQUEST_METHOD"] == "GET" && isset($_GET["id"])) 
{
    $id = $_GET["id"];

    try {
        $sql = "DELETE FROM files WHERE id=:id";
        $stmt= $dbHandler->prepare($sql);
        $data = [
            ':id' => $id
        ];
        $query_execute = $stmt->execute($data);

        if($query_execute)
        {
            echo "Deleted Successfully";
        }
        else
        {
            echo "Not Deleted";
        }

    } catch(Exception $ex){
        printError($ex);
    }
}

?>