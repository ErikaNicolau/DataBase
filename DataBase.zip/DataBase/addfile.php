<?php

include_once 'dbconnect_inc.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $my_folder = "files/";

    $file = $_FILES['URL'];
    $fileName = $_FILES['URL']['name'];
    $fileTmpName = $_FILES['URL']['tmp_name'];
    $fileSize = $_FILES['URL']['size'];
    $fileError = $_FILES['URL']['error'];
    $fileType = $_FILES['URL']['type'];

    $fileExt = explode('.', $fileName);
    $fileActualExt = strtolower(end($fileExt));

    $allowed = array('jpg', 'jpeg', 'png','pdf','doc','docx','xsl','xslx','txt','pdf');

    if (in_array($fileActualExt, $allowed)) {
        if ($fileError === 0) {
            if ($fileSize < 1000000) {
                if (file_exists($my_folder . $fileName)) {
                    echo 'Sorry, ' . $fileName . ' already exists.';
                } else {
                    $fileDestination = 'files/' . $fileName;
                    move_uploaded_file($fileTmpName, $fileDestination);
                    echo "File uploaded successfully!";
                }
            } else {
                echo "Your file is too big!";
            }
        } else {
            echo "There was an error uploading your file!";
        }
    } else {
        echo "You cannot upload files of this type!";
    }
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $file = isset($_FILES['URL']) ? $_FILES['URL']['name'] : '';
    $description = isset($_POST['description']) ? $_POST['description'] : '';
    $URL = isset($_FILES['URL']) ? $_FILES['URL']['name'] : '';
}

if (empty($file) || empty($description) || empty($URL)) {
    echo "All fields are required. Please fill in all the fields.";
} else {
    if ($dbHandler) {
        try {
            $sql = "INSERT INTO files (`File Name`, `File Description`, `URL`) VALUES (:file, :description, :URL)";
            $stmt = $dbHandler->prepare($sql);
            $stmt->bindParam(':file', $file, PDO::PARAM_STR);
            $stmt->bindParam(':description', $description, PDO::PARAM_STR);
            $stmt->bindParam(':URL', $URL, PDO::PARAM_STR);
            $stmt->execute();
            echo "Query executed! {$stmt->rowCount()} row(s) affected<br>";
            $stmt->closeCursor();
        } catch (Exception $ex) {
            printError($ex);
        }
    }
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="stylesheet.css" rel="stylesheet" type="text/css">
    <title>Add file</title>
</head>
<body>
<section class='login'>
    <div class='login-container'>
        <div class='login-box'>
    <h1>Add new file</h1>
    <form action="" method="POST" enctype='multipart/form-data'>
        <input type="text" name="description" placeholder="File Description">
        <input type="file" name="URL">
        <input type="submit" name="submit">
    </form>
    </div>
    </div>
</section>
</body>
</html>