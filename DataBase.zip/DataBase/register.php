<?php
$msgs = [];
if($_SERVER["REQUEST_METHOD"] == "POST"){
    if (!$user = filter_input(INPUT_POST, "un", FILTER_SANITIZE_SPECIAL_CHARS)) {
        $msgs[] = "Invalid username or no username given";
    } elseif (empty($user)) {
        $msgs[] = "Username cannot be empty";
    }

    if (!$pass = filter_input(INPUT_POST, "pw")) {
        $msgs[] = "No password given";
    }
    if (count($msgs) == 0) {
        require_once("dbconnect_inc.php");

        if ($dbHandler) {
            try {
                $checkStmt = $dbHandler->prepare("SELECT id FROM users WHERE username = :username");
                $checkStmt->bindParam("username", $user, PDO::PARAM_STR);
                $checkStmt->execute();

                if ($checkStmt->fetch(PDO::FETCH_ASSOC)) {
                    $msgs[] = "Username already exists. Please choose a different username.";
                } else {
                    $insertStmt = $dbHandler->prepare("INSERT INTO users (id, username, password) VALUES (NULL, :username, :hashedpass)");
                    $insertStmt->bindParam("username", $user, PDO::PARAM_STR);
                    $hashedPass = password_hash($pass, PASSWORD_BCRYPT);
                    $insertStmt->bindParam("hashedpass", $hashedPass, PDO::PARAM_STR);
                    $insertStmt->execute();

                    if ($insertStmt && $insertStmt->rowCount() == 1) {
                        $msgs[] = "Registration successful";
                    } else {
                        $msgs[] = "Invalid username or password";
                    }
                }
            } catch (Exception $ex) {
                printError($ex);
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="stylesheet.css" rel="stylesheet" type="text/css">
    <title>Register please</title>
</head>
<body>
<section class='login'>
    <div class='login-container'>
        <div class='login-box'>
    <h1>Register</h1>
    <?php
        if(count($msgs) > 0){
            foreach ($msgs as $msg) {
                echo $msg;
            }
        }
    ?>
    <form action="<?=htmlentities($_SERVER['PHP_SELF'])?>" method="post">
	<table>
		<tr>
			<td>
				Username:
			</td>
			<td>
				<input type="text" name="un" />
			</td>
		</tr>
		<tr>
			<td>Password:</td>
			<td>
				<input type="password" name="pw" />
			</td>
		</tr>
	</table>
	<input type="submit" name="submit" />
    <p><a href='login.php'>Log in</a>!
    </form>
        </div>
    </div>
</section>
</body>
</html>