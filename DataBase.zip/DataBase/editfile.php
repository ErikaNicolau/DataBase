<?php

include_once 'dbconnect_inc.php';

$new = [];

if ($_SERVER['REQUEST_METHOD'] == 'GET' && isset($_GET['id'])) {
    $id = $_GET['id'];

    try {
        $sql = "SELECT * FROM files WHERE `id` = :id";
        $stmt = $dbHandler->prepare($sql);
        $stmt->bindParam(':id', $id, PDO::PARAM_INT);
        $stmt->execute();
        $new = $stmt->fetch(PDO::FETCH_ASSOC);
    } catch (Exception $ex) {
        printError($ex);
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="stylesheet.css" rel="stylesheet" type="text/css">
    <title>Edit File</title>
</head>
<body>
<section class='login'>
    <div class='login-container'>
        <div class='login-box'>
    <h1>Edit File</h1>
    <form action="updatefile.php" method="POST">
    <input type="hidden" name="id" value="<?php echo isset($new['id']) ? $new['id'] : ''; ?>">
        <label for="product">File Name:</label>
        <input type="text" name="file" value="<?php echo isset($new['file']) ? $new['file'] : ''; ?>"><br>

        <label for="description">File Description:</label>
        <input type="text" name="description" value="<?php echo isset($new['description']) ? $new['description'] : ''; ?>"><br>

        <label for="URL">URL:</label>
        <input type="text" name="URL" value="<?php echo isset($new['URL']) ? $new['URL'] : ''; ?>"><br>

        <input type="submit" name="submit" value="Update">
    </form>
    </div>
    </div>
</section>
</body>
</html>